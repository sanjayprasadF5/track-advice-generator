const express = require("express");
const axios = require("axios");
const querystring = require("querystring");
const jwt = require("jsonwebtoken");
const router = express.Router();

// Login route to initiate Spotify OAuth flow
router.get("/login", (req, res) => {
  const scopes = "user-top-read";
  const redirectUri = process.env.REDIRECT_URI;
  const clientId = process.env.SPOTIFY_CLIENT_ID;
  const authUrl = `https://accounts.spotify.com/authorize?${querystring.stringify(
    {
      response_type: "code",
      client_id: clientId,
      scope: scopes,
      redirect_uri: redirectUri,
    }
  )}`;
  res.redirect(authUrl);
});

// Callback route to handle Spotify's response
router.get("/callback", async (req, res) => {
  const code = req.query.code || null;
  const clientId = process.env.SPOTIFY_CLIENT_ID;
  const clientSecret = process.env.SPOTIFY_CLIENT_SECRET;
  const redirectUri = process.env.REDIRECT_URI;

  console.log("Received code:", code);

  try {
    const tokenResponse = await axios.post(
      "https://accounts.spotify.com/api/token",
      querystring.stringify({
        code,
        redirect_uri: redirectUri,
        grant_type: "authorization_code",
      }),
      {
        headers: {
          Authorization: `Basic ${Buffer.from(
            `${clientId}:${clientSecret}`
          ).toString("base64")}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        httpsAgent: new (require("https").Agent)({ rejectUnauthorized: false }), // Ignore SSL validation
      }
    );

    console.log("Token response:", tokenResponse.data);

    const accessToken = tokenResponse.data.access_token;
    const userResponse = await axios.get("https://api.spotify.com/v1/me", {
      headers: { Authorization: `Bearer ${accessToken}` },
      httpsAgent: new (require("https").Agent)({ rejectUnauthorized: false }), // Ignore SSL validation
    });

    console.log("User response:", userResponse.data);

    const userId = userResponse.data.id;
    const jwtToken = jwt.sign({ sub: userId }, process.env.JWT_SECRET, {
      expiresIn: "1h",
    });

    res.json({ jwt: jwtToken });
  } catch (error) {
    console.error(
      "Error during callback:",
      error.response ? error.response.data : error.message
    );
    res.status(500).json({ error: "Authentication failed" });
  }
});

module.exports = router;
