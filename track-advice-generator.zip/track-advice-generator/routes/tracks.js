const express = require("express");
const axios = require("axios");
const jwt = require("jsonwebtoken");
const Track = require("../models/Track");

const router = express.Router();

const authenticateJWT = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.sendStatus(403);

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

router.get("/tracks", authenticateJWT, async (req, res) => {
  try {
    const accessToken = req.headers.authorization.split(" ")[1];
    console.log("Access Token:", accessToken);

    const topTracksResponse = await axios.get(
      "https://api.spotify.com/v1/me/top/tracks?limit=5",
      {
        headers: { Authorization: `Bearer ${accessToken}` },
      }
    );

    console.log("Top Tracks Response:", topTracksResponse.data);

    const tracks = topTracksResponse.data.items.map((track) => ({
      spotifyUserId: req.user.sub,
      name: track.name,
      artist: track.artists[0].name,
    }));

    for (const track of tracks) {
      const adviceResponse = await axios.get(
        "https://api.adviceslip.com/advice"
      );
      console.log("Advice Response:", adviceResponse.data);

      track.advice = adviceResponse.data.slip.advice;
      await Track.create(track);
    }

    res.json(tracks);
  } catch (error) {
    console.error(
      "Error:",
      error.response ? error.response.data : error.message
    );
    res.status(500).json({ error: "Failed to fetch tracks or advice" });
  }
});

module.exports = router;
