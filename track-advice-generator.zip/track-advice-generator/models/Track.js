const mongoose = require("mongoose");

const trackSchema = new mongoose.Schema({
  spotifyUserId: String,
  name: String,
  artist: String,
  advice: String,
});

module.exports = mongoose.model("Track", trackSchema);
