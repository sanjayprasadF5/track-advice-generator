const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const dotenv = require("dotenv");

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

mongoose
  .connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("MongoDB connected"))
  .catch((err) => console.error(err));

// Import and use the auth routes
const authRoutes = require("./routes/auth");
app.use("/auth", authRoutes);

// Import and use the tracks routes
const trackRoutes = require("./routes/tracks");
app.use("/api", trackRoutes);

app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});
